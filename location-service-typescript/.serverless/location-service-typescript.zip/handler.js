'use strict';
Object.defineProperty(exports, "__esModule", { value: true });
const geolib = require("geolib");
const capitals = require('./capitals.json');
const endpoint = (event, context, callback) => {
    const locations = capitals.reduce((object, location) => {
        object[location.capital] = {
            latitude: location.latitude,
            longitude: location.longitude
        };
        return object;
    }, {});
    const location = {
        latitude: event.pathParameters.latitude,
        longitude: event.pathParameters.longitude
    };
    const response = {
        statusCode: 200,
        body: JSON.stringify(geolib.findNearest(location, locations, 0, 4))
    };
    callback(null, response);
};
exports.endpoint = endpoint;
