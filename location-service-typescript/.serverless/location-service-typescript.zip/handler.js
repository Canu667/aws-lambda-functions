'use strict';
Object.defineProperty(exports, "__esModule", { value: true });
const geolib = require("geolib");
const capitals_json_1 = require("./capitals.json");
const endpoint = (event, context, callback) => {
    // const locations = {
    //     a: {latitude: 52.516272, longitude: 13.377722},
    //     b: {latitude: 51.518, longitude: 7.45425},
    //     c: {latitude: 51.503333, longitude: -0.119722}
    // };
    const locations = capitals_json_1.default.map((location) => {
        let name = `${location.country},${location.capital}`;
        return {
            name: {
                "latitude": location.latitude,
                "longitude": location.longitude
            }
        };
    });
    // const locations = {
    //     "Brandenburg Gate, Berlin": {latitude: 52.516272, longitude: 13.377722},
    //     "Dortmund U-Tower": {latitude: 51.515, longitude: 7.453619},
    //     "London Eye": {latitude: 51.503333, longitude: -0.119722},
    //     "Kremlin, Moscow": {latitude: 55.751667, longitude: 37.617778},
    //     "Eiffel Tower, Paris": {latitude: 48.8583, longitude: 2.2945},
    //     "Riksdag building, Stockholm": {latitude: 59.3275, longitude: 18.0675},
    //     "Royal Palace, Oslo": {latitude: 59.916911, longitude: 10.727567}
    // }
    const location = {
        latitude: event.pathParameters.latitude,
        longitude: event.pathParameters.longitude
    };
    const response = {
        statusCode: 200,
        body: JSON.stringify(geolib.findNearest(location, locations, 0, 4))
    };
    callback(null, response);
};
exports.endpoint = endpoint;
